module.exports={
    mongoURI : 'mongodb://admin:admin123@ds247674.mlab.com:47674/storyboard',
    googleClientID:
    '404600200065-tq30gfm130pmpueh040e15eg3vb84sm4.apps.googleusercontent.com',
    googleClientSecret: 'HwPL-oMYf_yDUJOATHpuihx6'

}